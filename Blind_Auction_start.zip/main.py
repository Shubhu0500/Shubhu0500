from replit import clear
#HINT: You can call clear() to clear the output in the console.
from art import logo
print(logo)
bidders = {}
max_length = 1

while len(bidders) < max_length:
    name = input("What is your name? ")
    bid = input("What is your bid? $")
    bidders[name] = bid
    game_continue = True
    game_continue = input("Are there any other bidders? 'Yes' or 'No' ").lower()
    if game_continue == "yes":
      max_length += 1
      clear()
    else:
      game_continue = False
       
  
# Getting the key with maximum value  
max_name = max(zip(bidders.values(), bidders.keys()))[1]  
maximum = max(zip(bidders.values(), bidders.keys()))[0] 
print(f"The winner is {max_name} with a bid of {maximum}")

